﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steganografia
{
    public partial class Form3 : Form
    {
        string messaggio;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            OpenFileDialog apri = new OpenFileDialog();     //variabile di tipo "carica file"
            apri.Filter = "File immagine(*.jpg; *.jpeg; *.gif; *.png; *.bmp) | *.jpg; *.jpeg; *.gif; *.png; *.bmp";     //filtro per poter inserire solo immagini
            if (apri.ShowDialog() == DialogResult.OK)       //se il caricamento del file avviene con successo
            {
                pictureBox1.Image = new Bitmap(apri.FileName);      //metto l'immagine caricata nella picturebox
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            OpenFileDialog apriModificata = new OpenFileDialog();
            apriModificata.Filter = "File immagine(*.jpg; *.jpeg; *.gif; *.png; *.bmp) | *.jpg; *.jpeg; *.gif; *.png; *.bmp";     //filtro per poter inserire solo immagini
            if (apriModificata.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Image = new Bitmap(apriModificata.FileName);
                pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            estrapolazione(pictureBox1.Image, pictureBox2.Image);
            string[] caratteri = messaggio.Split(' ');
            foreach (string x in caratteri)
            {
                int temp = conversioneDecBin(x);
                label2.Text += (char)temp;
            }
        }

        private int conversioneDecBin(string x){
            int dec = 0, esponente = 0;
            for(int i = 7; i >= 0; i--)
            {
                int potenza = (int) Math.Pow(2,esponente);
                dec += x[i] - 48 * potenza;
                esponente++;
            }
            return dec;
        }

        private void estrapolazione(Image img1, Image img2)
        {
            int[] testo = new int[8];
            int conta = 0;
            bool controllo = false;
            for(int i = 0; i < img1.Height && controllo == false; i++)
            {
                for(int j = 0; i < img1.Width && controllo == false; i++)
                {
                    Color immagine1 = (img1 as Bitmap).GetPixel(j, i);
                    Color immagine2 = (img2 as Bitmap).GetPixel(j, i);
                    testo[conta] = (immagine1.R & immagine2.R);             //controlla la portante Rossa delle due immagini
                    conta++;
                    if(conta == 8)
                    {
                        string temp = Convert.ToString(testo);
                        if (temp == "00000100")
                            controllo = true;
                        else
                        {
                            conta = 0;
                            messaggio += " " + Convert.ToString(testo);
                            azzeramento(testo, 8);
                        }                       
                    }
                    testo[conta] = (immagine1.G & immagine2.G);             //controlla la portante Verde delle due immagini
                    conta++;
                    if (conta == 8)
                    {
                        string temp = Convert.ToString(testo);
                        if (temp == "00000100")
                            controllo = true;
                        else
                        {
                            conta = 0;
                            messaggio += "." + Convert.ToString(testo);
                            azzeramento(testo, 8);
                        }
                    }
                    testo[conta] = (immagine1.B & immagine2.B);             //controlla la portante Blu delle due immagini
                    conta++;
                    if (conta == 8)
                    {
                        string temp = Convert.ToString(testo);
                        if (temp == "00000100")
                            controllo = true;
                        else
                        {
                            conta = 0;
                            messaggio += "." + Convert.ToString(testo);
                            azzeramento(testo, 8);
                        }
                    }
                }
            }
        }

        private void azzeramento(int[] vet, int dim)
        {
            for(int i = 0; i < dim; i++)
            {
                vet[i] = 0;
            }
        }

        //private string ConvertitoreBD(int [])
    }
}
